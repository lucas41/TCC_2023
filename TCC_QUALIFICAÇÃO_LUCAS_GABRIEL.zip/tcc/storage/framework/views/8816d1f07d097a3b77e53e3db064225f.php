

<?php
$nome = session('nome');
echo("seja bem vindo  $nome");

?>

<a href="/logout">Sair</a><?php /**PATH C:\Users\user\Desktop\TCC\TCC_2023\tcc\resources\views/main/home.blade.php ENDPATH**/ ?>