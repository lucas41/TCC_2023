

<?php
$nome = session('nome');
echo("seja bem vindo  $nome");

?>

<a href="/logout">Sair</a>